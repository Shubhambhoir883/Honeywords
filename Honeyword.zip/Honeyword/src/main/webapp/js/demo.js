function fun1()
{   
    var list = '<%= arrayList %>';
    alert('string message');
}