-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 17, 2015 at 06:26 PM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `honeyword`
--

-- --------------------------------------------------------

--
-- Table structure for table `decoy`
--

CREATE TABLE IF NOT EXISTS `decoy` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `created_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `decoy`
--

INSERT INTO `decoy` (`id`, `name`, `created_time`) VALUES
(1, 'Fast Cluster Execution.doc', '2015-08-13 18:36:20');

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE IF NOT EXISTS `files` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `user_id` int(20) NOT NULL,
  `created_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`id`, `name`, `user_id`, `created_time`) VALUES
(1, 'Createfile.txt', 1, '2015-08-13 18:40:12'),
(2, 'HashData.java', 1, '2015-08-14 14:56:27');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE IF NOT EXISTS `logs` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `user_desc` varchar(500) NOT NULL,
  `action_desc` varchar(500) NOT NULL,
  `created_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`id`, `user_desc`, `action_desc`, `created_time`) VALUES
(1, 'Hacker Who Attempt Three time Password', 'Hacker is trying to access  account having IP Address as and attempt password combination three times', '2015-08-17 16:46:55'),
(2, 'Hacker Who Attempt Three time Password', 'Hacker is trying to access  account having IP Address as and attempt password combination three times', '2015-08-17 16:52:01');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(2000) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `position` int(10) NOT NULL,
  `gender` enum('Male','Female') NOT NULL,
  `created_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `phone`, `position`, `gender`, `created_time`) VALUES
(1, 'Anurath', 'c3cf9a4e7f42434e7a2eee674ac808636beef46d647c0a694f168841074ac,3119c5da4dad4fdfe8badc41839f1e7fcf1a0a6d6ff1cc0b896136b061cff0,71cd1b33f32a2a74a0d1b8334e15cecebc94c3e5f990496da7d3a9632a96,6f267492c591996cc34c2fce747873ea4985b432115b112a6d4f48485b58ccb,68f461719146c9f7f4b41864329df6d8c388294ddf466af17cf058a3e27b6ef0,9c23e014dfb483befdc24a357bb5e83791e4dd1c2b9f995d8a1cd26affc96bf,854ab2cab4f73e441f1ced449e66308255c694e02c3bccc90787560f0583a,263d631357ac7f1398cd54dcf8863511f49bb4338673d74e0411622ec9ed9c,bf68a32ce732f4915c3de9320e9d9358d6742c05fc3358e5af33e544e51e9,bef5839a942c184a8e93af8a79d237520e039133084332a23a581a29a7b1d5,d08e926a4bb313881294d9f722313cb174d817fd25d896b63d0eef9e2ae95d4,b7718b34e2563db162c3279b19bcb708e5e6bcd3af6020b12fed13f5a9c6de,7d8441f1c7787a1e79782243edd745762955205cda51af3d8bc748d3686cc4b,806c4e70c5d19b19fcbb51024fafb27d0829cdb6955b4db8d7fe0ea7cac,a5fbd22250b15c887ae7bad67c4ef590759bd53b9e3aa126bbf5896b8136f3,6dd49aedb3f7b76c1e6a6711a7edf3b4b51b7f99b48a28271d9e9ec329ed4a,7b4e2013306e2986132fa1e5b3a1bb6fd9549f12d82a675b2157ad5adf19b32,30ffbe539858fb13b3e49dcc8d8ed2c1be6a4fce264b593297294abc117ead,eb2e427067b4dda9cb39163e11c6e92ec7fc9cbd9541e9e95f449f4791618fd9,d949d39d236b99347ac5f019a3931518f88b2591617cfdcc7f355c26c3ff49d', 'anurathmane@gmail.com', '9004529180', 9, 'Male', '2015-08-12 15:24:42'),
(2, 'Chetan', '56f57643221c3c1a5e32ad393956164d93e561a7c4990103fe07c3edcaf89,72f4ee5f8d58f6218fb41a834b631f271cef54e22db839b6645b734bfb0e9b0,8bdd78fb580dafe2f248c3f6ec9f2896b26c24aeae6bcfbb241613ce4add2,1841bea5d19d235fc1fe62129e5c844692d3cdc0dfcbe0169025ca1ff24136,5f36e818b74e6f4cdf7458fb288bed30328d9d7014df2a77995ec3859cef2,fbf54dbcffea3ba4abfb32f4a8fc97477525149bd5c3d5631be12db797e5b60,1856d2f4c11df7eafc3c6281ac081f8f190688da1fc9c346dee69673cad40a2,bc77f8c0638f74c5bec5e3f8ecb92b4f9ca27678cd42dbb1ce4d97c72a1f8a1,61dcbee594ca5bf7e990628bb2faaa65996e81027f946f89f78e240c9c4f3,8212c9c5e7e86488ef65354d29172ad4bbff1a7d8ffa46c44ab7a1aebb3,96f2ce886fd03c185e53de1636f2c5c2581da1af5fe4fcdc61cf22a3d9611,b0781a88edb823a84dbdedc52361b93c2f37f030aa36ad654d62d2d5b4dfaca8,f3a56a127d68582137586d65d5f642fe8b2bf92e1b4794b3b347a81a8598e,9b8b5d4952414cf0eb16e6304fdf2ae11f1984df85fae1574cdaeace5ec887ff,38e213b98fcf42edbbb9c93ef3127b69777e713a8fb2669597d7bcb035374b,89d1731b958231918b1198ae6a1f1a48cb2bf8efd2a5d26fbd9689ad7c4ac933,2d33b3df8d62dbdcbf78cf52151e0f0a16c2f71a019ad953490a98a467d25e6,c84ac2343a9e43893f88957def91c6b026c662a3d77df48de850777c63ea538f,3044db50ef706d22af53387377de6d3b22485524bfe4d88b2474bc97b4a262,acec53b41978f64f67e14c3e60654e9bbba0e9be872458a866ce418555151cc', 'chetanc.eiosys@gmail.com', '9764538841', 4, 'Male', '2015-08-12 15:26:38');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
